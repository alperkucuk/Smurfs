/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication61;

/**
 *
 * @author TOSHIBA
 */
public class dusman {
    //dusmanID, dusmanAdi ve dusmanTür
    private int dusmanid;
    private String dusmanadi;
    private String dusman_tur;

    public dusman(int dusmanid, String dusmanadi, String dusman_tur) {
        this.dusmanid = dusmanid;
        this.dusmanadi = dusmanadi;
        this.dusman_tur = dusman_tur;
    }
    
    
}
