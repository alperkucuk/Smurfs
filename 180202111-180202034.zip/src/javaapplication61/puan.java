
package javaapplication61;

public class puan extends oyuncu{
    
    public puan(int id, String ad, String tur, int skor) {
        super(id, ad, tur, skor);
    }

    @Override
    public void puani_goster() {
        super.puani_goster();
    }
    
    
}
